#include "lab01_1b.h"

void SpiralSorrend(const int* matrix, int n, int* spiral)
{
	
}