#pragma once

#include <iostream>
#include <fstream>

using namespace std;

// SpiralSorrend(const int* matrix, int n, int* spiral);