#include "lab01_1b.h"

void main()
{
	int n;
	const int* matrix;
	int seged;
	int* p;
	
	ifstream f("input_lab01_1b.txt");

	f >> n;
	int matrix_len = n * n;

	cout << matrix_len << endl;

	p = matrix;
	for (int i = 1; i <= matrix_len; i++)
	{
		f >> seged;
		matrix = &seged;
		matrix++;
	}

	for (int i = 1; i <= matrix_len; i++)
	{
		seged = *matrix;
		matrix++;
		cout << seged << " ";
	}
}